CKEDITOR.plugins.setLang(
	
	
		'doksoft_image',
	
	
	
	
	'en',
	{	
		
			doksoft_image:
		
		
		
		{
				
					button_label: "Insert image",
				
				
					resize: "Max size",
					resize_up: "Scale up if small image",
				
				
				
				
				
					dlg_title: "Insert image",
				
				
				
				
				
				
				status_file_upload: "File uploading...",
				status_file_upload_success: "File upload success. Click OK to continue",
				status_file_upload_wait: "Uploading file. Wait...",
				status_file_upload_fail: "Unable to upload the file. Try again or use another file.",
				
				label_send_to_server: "Send to server",
				
				label_no_file: "You did not upload a file",
				
				label_no_support: "Loading..."
		}
	}
);

CKEDITOR.plugins.setLang(
	
	
		'doksoft_image',
	
	
	
	
	'ru',
	{	
		
			doksoft_image:
		
		
		
		{
				
					button_label: "Вставить изображение",
				
				
					resize: "Макс. размер",
					resize_up: "Масштабировать в сторону увеличения",
				
				
				
				
				
					dlg_title: "Вставка изображения",
				
				
				
				
				
				
				status_file_upload: "Загрузка файла...",
				status_file_upload_success: "Файл успешно загружен, нажмите ОК для продолжения",
				status_file_upload_wait: "Файл загружается. Подождите...",
				status_file_upload_fail: "Не удалось загрузить файл. Попытайтесь снова или попробуйте загрузить другой файл.",
				
				label_send_to_server: "Отправить на сервер",
				
				label_no_file: "Вы еще не загрузили файл на сервер",
				
				label_no_support: "Загрузка..."
		}
	}
);
